from typing import Dict, Union
from engine.domain.interfaces.ichart_operation import IChartOperation
from engine.chart_section import ChartSection
from engine.data.models.validation_results import ValidationResult
from engine.data.models.pattern_context import PatternContext

class AddRowOperation(IChartOperation):
    """Operation to add a row to the chart."""
    
    def execute(self, chart: ChartSection, params: Dict) -> ChartSection:
        """Add a new row to the pattern."""
        pattern = params.get('pattern')
        is_round = params.get('is_round', False)
        
        if pattern is None:
            raise ValueError("Pattern is required for add_row operation")
        
        if isinstance(pattern, int):
            new_row = chart.row_manager.duplicate_row(pattern)
            # For duplicate_row, consumed and produced are the same (no net change)
            consumed = len(new_row)
            produced = len(new_row)
        else:
            side = "WS" if chart.row_manager.is_wrong_side(is_round) else "RS"
            expanded = chart.pattern_parser.expand_pattern(
                pattern, 
                chart.node_manager.get_last_row_produced(), 
                chart.row_manager.get_last_row_side()
            )
            new_row = expanded.stitches
            consumed = expanded.consumed
            produced = expanded.produced
            markers = expanded.markers
            
            for marker in markers:
                chart.marker_manager.add_marker(side, marker, len(new_row))
                chart._notify_marker_placed(side, marker)
        
        # Validate stitch count after pattern expansion (only stitch counts, not pattern syntax)
        # Pattern syntax is validated by the pattern parser during expansion
        if chart.validation_chain is not None:
            from engine.data.models.validation_request import ValidationRequest
            from engine.data.models.pattern_context import PatternContext
            
            last_row_side = chart.row_manager.get_last_row_side()
            context = PatternContext(
                available_stitches=chart.get_current_num_of_stitches(),
                side=last_row_side,
                markers=chart.marker_manager.get_markers(last_row_side),
                last_row_side=last_row_side,
                is_round=is_round
            )
            
            # Only validate stitch counts, not pattern syntax
            # Pass None for pattern to skip pattern validation
            request = ValidationRequest(
                chart=chart,
                operation="add_row",
                context=context,
                consumed=consumed,
                produced=produced,
                pattern=None  # Skip pattern syntax validation - already done by parser
            )
            validation_result = chart.validation_chain.handle(request)
            if not validation_result.is_valid:
                raise ValueError(f"Stitch count validation failed: {', '.join(validation_result.errors)}")
        
        new_row = chart.row_manager.reverse_row_if_needed(new_row, is_round)
        old_count = chart.node_manager.get_last_row_produced()
        chart.add_nodes(new_row, side, is_round)
        
        # Use update method for controlled state update
        chart.node_manager.update_last_row_produced(consumed, produced)
        new_count = chart.node_manager.get_last_row_produced()
        
        # Record operation in stitch counter
        chart.stitch_counter.record_operation("add_row", consumed, produced)
        
        if old_count != new_count:
            chart._notify_stitch_count_changed(old_count, new_count)
        
        return chart
    
    def validate(self, params: Dict, context: PatternContext) -> ValidationResult:
        """Validate the add row operation."""
        errors = []
        pattern = params.get('pattern')
        
        if pattern is None:
            errors.append("Pattern is required for add_row operation")
        elif isinstance(pattern, str) and len(pattern.strip()) == 0:
            # Allow empty patterns - they may be used for special operations like place_on_hold
            # The pattern parser will handle empty patterns appropriately
            pass
        elif isinstance(pattern, int) and pattern < 0:
            errors.append("Row index must be non-negative")
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors
        )